# Smart Home - Programação Socket

Projeto didático em Python com sockets TCP e threads.

## Arquivos
- `servidor.py`: aceita conexões, valida IDs, encaminha comandos e registra eventos.
- `cliente.py`: permite simular os cinco tipos de dispositivo.
- `registro.log`: arquivo de registro criado pelo servidor ao executar.

## Como executar
1. Instale Python 3.
2. Abra a pasta no PyCharm.
3. Execute `servidor.py` primeiro e deixe-o aberto.
4. Execute `cliente.py` em outra janela/instância.
5. Escolha o dispositivo e o cômodo.
6. Para testar comunicação entre dispositivos, execute vários clientes em paralelo.

## IDs de dispositivo
- Lâmpada: `LAMP-SALA`, `LAMP-QUARTO1`, `LAMP-QUARTO2`
- Tomada: `TOM-SALA`, `TOM-QUARTO1`, `TOM-QUARTO2`
- Sensor: `SEN-SALA`, `SEN-QUARTO1`, `SEN-QUARTO2`
- Ar-condicionado: `AR-SALA`, `AR-QUARTO1`, `AR-QUARTO2`
- Termômetro: `TERM-SALA`, `TERM-QUARTO1`, `TERM-QUARTO2`

Cada ID só pode ter uma conexão ativa por vez.

## Protocolo
Registro: `ID|REGISTRO:tipo:comodo`
Exemplo: `TERM-SALA|REGISTRO:termometro:sala`

Mensagens de controle:
- `TERM-SALA|TEMPERATURA:30`
- `SEN-SALA|PRESENCA:1`
- `SEN-SALA|PRESENCA:0`
- `TOM-SALA|CONSUMO:120`
- Comandos enviados: `AR-SALA|LIGAR:22`, `AR-SALA|DESLIGAR`, `LAMP-SALA|LIGAR`, `LAMP-SALA|DESLIGAR`

## Regras implementadas
- Temperatura acima de 28 °C: envia comando para ligar o ar a 22 °C.
- Temperatura igual ou abaixo de 28 °C: envia comando para desligar o ar.
- Presença `1`: liga a lâmpada e agenda desligamento após 10 minutos.
- Presença `0`: envia comando para desligar a lâmpada.
- Tomada: registra o consumo informado manualmente.
- Eventos e mensagens são gravados em `registro.log`.

## Como visualizar o registro
O arquivo `registro.log` é criado na pasta de trabalho usada para executar o servidor. Abra-o com o PyCharm ou um editor de texto. Se não aparecer imediatamente, envie uma mensagem pelo cliente para gerar o primeiro registro.

## Observações
O sistema é uma simulação por terminal. Não controla equipamentos físicos. O consumo da tomada é digitado pelo usuário; a geração automática de consumo a cada dois minutos não está implementada neste exemplo. Teste e adapte o projeto conforme as orientações do professor.
