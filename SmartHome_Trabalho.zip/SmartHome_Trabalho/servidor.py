import socket
import threading
import logging
import time

HOST = "127.0.0.1"
PORTA = 9999

# Registro das mensagens em arquivo e no terminal.
logging.basicConfig(
    filename="registro.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    encoding="utf-8"
)

clientes = {}       # ID -> dados do dispositivo
bloqueio = threading.Lock()
temporizadores_lampadas = {}


def registrar(texto):
    print(texto)
    logging.info(texto)


def enviar_comando(dispositivo_id, comando):
    """Envia uma mensagem no formato ID|MENSAGEM_DE_CONTROLE."""
    with bloqueio:
        dados = clientes.get(dispositivo_id)
        conexao = dados["conexao"] if dados else None

    if conexao:
        try:
            mensagem = f"{dispositivo_id}|{comando}\n"
            conexao.sendall(mensagem.encode("utf-8"))
            registrar(f"[ENVIO] {mensagem.strip()}")
            return True
        except OSError as erro:
            registrar(f"[ERRO] Falha ao enviar para {dispositivo_id}: {erro}")
    else:
        registrar(f"[AVISO] Dispositivo {dispositivo_id} nao conectado.")
    return False


def desligar_lampada_depois(lampada_id, atraso=600):
    """Desliga a lampada apos 10 minutos, se ela continuar conectada."""
    def tarefa():
        time.sleep(atraso)
        enviar_comando(lampada_id, "DESLIGAR")
        with bloqueio:
            temporizadores_lampadas.pop(lampada_id, None)

    with bloqueio:
        anterior = temporizadores_lampadas.get(lampada_id)
        if anterior and anterior.is_alive():
            # Um novo evento de presenca reinicia o prazo.
            temporizadores_lampadas.pop(lampada_id, None)
        temporizador = threading.Thread(target=tarefa, daemon=True)
        temporizadores_lampadas[lampada_id] = temporizador
        temporizador.start()


def tratar_cliente(conexao, endereco):
    dispositivo_id = None
    try:
        arquivo = conexao.makefile("r", encoding="utf-8", newline="\n")
        primeira = arquivo.readline().strip()
        partes = primeira.split("|", 2)

        # Registro: ID|REGISTRO:tipo:comodo
        if len(partes) != 2 or not partes[1].startswith("REGISTRO:"):
            registrar(f"[ERRO] Registro invalido recebido de {endereco}.")
            return

        dispositivo_id = partes[0].strip().upper()
        dados_registro = partes[1][len("REGISTRO:"):].split(":", 1)
        if len(dados_registro) != 2:
            registrar(f"[ERRO] Dados de registro invalidos: {primeira}")
            return

        tipo = dados_registro[0].lower().strip()
        comodo = dados_registro[1].lower().strip()
        tipos_validos = {"lampada", "tomada", "presenca", "ar", "termometro"}
        comodos_validos = {"sala", "quarto1", "quarto2"}

        if tipo not in tipos_validos or comodo not in comodos_validos:
            registrar(f"[ERRO] Tipo ou comodo invalido: {primeira}")
            return

        with bloqueio:
            if dispositivo_id in clientes:
                registrar(f"[AVISO] ID ja conectado: {dispositivo_id}")
                return
            clientes[dispositivo_id] = {
                "conexao": conexao,
                "tipo": tipo,
                "comodo": comodo
            }

        registrar(f"[CONECTADO] ID={dispositivo_id}, tipo={tipo}, comodo={comodo}, endereco={endereco}")

        for linha in arquivo:
            mensagem = linha.strip()
            if not mensagem:
                continue

            # Mensagem de controle: ID|COMANDO:VALOR
            campos = mensagem.split("|", 1)
            if len(campos) != 2:
                registrar(f"[ERRO] Mensagem fora do protocolo: {mensagem}")
                continue

            id_mensagem, controle = campos[0].strip().upper(), campos[1].strip()
            if id_mensagem != dispositivo_id:
                registrar(f"[ERRO] ID da mensagem nao corresponde ao cliente: {mensagem}")
                continue

            registrar(f"[RECEBIDO] {mensagem}")
            controle_maiusculo = controle.upper()

            if tipo == "termometro":
                if controle_maiusculo.startswith("TEMPERATURA:"):
                    try:
                        temperatura = float(controle.split(":", 1)[1].replace(",", "."))
                        ar_id = f"AR-{comodo.upper()}"
                        if temperatura > 28:
                            enviar_comando(ar_id, "LIGAR:22")
                        else:
                            enviar_comando(ar_id, "DESLIGAR")
                    except ValueError:
                        registrar("[AVISO] Temperatura invalida.")

            elif tipo == "presenca":
                if controle_maiusculo == "PRESENCA:1":
                    lampada_id = f"LAMP-{comodo.upper()}"
                    if enviar_comando(lampada_id, "LIGAR"):
                        desligar_lampada_depois(lampada_id)
                elif controle_maiusculo == "PRESENCA:0":
                    enviar_comando(f"LAMP-{comodo.upper()}", "DESLIGAR")

            elif tipo == "tomada":
                if controle_maiusculo.startswith("CONSUMO:"):
                    try:
                        consumo = float(controle.split(":", 1)[1].replace(",", "."))
                        if consumo < 0:
                            registrar("[AVISO] O consumo nao pode ser negativo.")
                        else:
                            registrar(f"[CONSUMO] {dispositivo_id}: {consumo} W informados.")
                    except ValueError:
                        registrar("[AVISO] Valor de consumo invalido.")

            elif tipo in {"lampada", "ar"}:
                registrar(f"[ESTADO] {dispositivo_id}: {controle}")

    except (ConnectionError, OSError, UnicodeError) as erro:
        registrar(f"[ERRO DE CONEXAO] {endereco}: {erro}")
    finally:
        if dispositivo_id:
            with bloqueio:
                dados = clientes.get(dispositivo_id)
                if dados and dados["conexao"] is conexao:
                    del clientes[dispositivo_id]
            registrar(f"[DESCONECTADO] {dispositivo_id}")
        try:
            conexao.close()
        except OSError:
            pass


def main():
    servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    servidor.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    servidor.bind((HOST, PORTA))
    servidor.listen()
    registrar(f"=== SERVIDOR SMART HOME iniciado em {HOST}:{PORTA} ===")
    registrar("Aguardando dispositivos...")

    try:
        while True:
            conexao, endereco = servidor.accept()
            threading.Thread(
                target=tratar_cliente,
                args=(conexao, endereco),
                daemon=True
            ).start()
    except KeyboardInterrupt:
        registrar("Servidor encerrado pelo usuario.")
    finally:
        servidor.close()


if __name__ == "__main__":
    main()
