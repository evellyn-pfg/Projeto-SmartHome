import socket
import threading
import random
import time

HOST = "127.0.0.1"
PORTA = 9999


def receber_mensagens(conexao, tipo):
    arquivo = conexao.makefile("r", encoding="utf-8", newline="\n")

    try:
        for linha in arquivo:
            mensagem = linha.strip()

            if not mensagem:
                continue

            print(f"\n[PROTOCOLO RECEBIDO] {mensagem}")

            if tipo == "lampada":
                if "LIGAR" in mensagem.upper():
                    print("Lampada ligada.")
                elif "DESLIGAR" in mensagem.upper():
                    print("Lampada desligada.")

            elif tipo == "ar":
                if "LIGAR" in mensagem.upper():
                    print("Ar-condicionado ligado com temperatura de 22 graus.")
                elif "DESLIGAR" in mensagem.upper():
                    print("Ar-condicionado desligado.")

            print("> ", end="", flush=True)

    except OSError:
        pass


print("\n=== SMART HOME - CLIENTE ===")
print("1 - Lampada")
print("2 - Tomada")
print("3 - Sensor de presenca")
print("4 - Ar-condicionado")
print("5 - Termometro")
print("0 - Sair")

dispositivos = {
    "1": ("lampada", "LAMP"),
    "2": ("tomada", "TOM"),
    "3": ("presenca", "SEN"),
    "4": ("ar", "AR"),
    "5": ("termometro", "TERM")
}

opcao = input("Escolha o dispositivo: ").strip()

if opcao == "0":
    raise SystemExit

if opcao not in dispositivos:
    print("Opcao invalida.")
    raise SystemExit

tipo, prefixo = dispositivos[opcao]

comodo = input("Comodo (sala, quarto1, quarto2): ").strip().lower()

if comodo not in {"sala", "quarto1", "quarto2"}:
    print("Comodo invalido.")
    raise SystemExit

dispositivo_id = f"{prefixo}-{comodo.upper()}"

try:
    conexao = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    conexao.connect((HOST, PORTA))

    conexao.sendall(
        f"{dispositivo_id}|REGISTRO:{tipo}:{comodo}\n".encode("utf-8")
    )

    threading.Thread(
        target=receber_mensagens,
        args=(conexao, tipo),
        daemon=True
    ).start()

    print(f"\nDispositivo conectado: {dispositivo_id}")

    if tipo == "tomada":
        print("Gerando consumo aleatorio a cada 2 minutos.")

        while True:
            consumo = random.randint(50, 500)
            mensagem = f"{dispositivo_id}|CONSUMO:{consumo}\n"

            conexao.sendall(mensagem.encode("utf-8"))
            print(f"[CONSUMO ENVIADO] {consumo} W")

            time.sleep(120)

    else:
        while True:
            texto = input("> ").strip()

            if texto.lower() == "sair":
                break

            if not texto:
                continue

            if tipo == "termometro":
                controle = f"TEMPERATURA:{texto}"

            elif tipo == "presenca":
                controle = f"PRESENCA:{texto}"

            elif tipo in {"lampada", "ar"}:
                controle = f"ESTADO:{texto.upper()}"

            mensagem = f"{dispositivo_id}|{controle}\n"
            conexao.sendall(mensagem.encode("utf-8"))

except ConnectionRefusedError:
    print("Inicie o servidor primeiro.")

except OSError as erro:
    print(f"Erro: {erro}")

finally:
    try:
        conexao.close()
    except (NameError, OSError):
        pass

    print("Cliente encerrado.")